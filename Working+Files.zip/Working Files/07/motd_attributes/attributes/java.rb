default['motd_attributes']['java_home'] = '/opt/java'
default['motd_attributes']['java_bin'] = '/opt/java/bin/java'
