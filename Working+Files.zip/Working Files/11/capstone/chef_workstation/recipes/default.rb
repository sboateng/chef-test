#
# Cookbook:: chef_workstation
# Recipe:: default
#
# Copyright:: 2017, The Authors, All Rights Reserved.

include_recipe 'git'
include_recipe 'chefdk'
include_recipe 'atom'
