name 'build_cookbook'
maintainer 'Mischa Taylor'
maintainer_email 'mischa@misheska.com'
license 'apachev2'
version '0.1.0'

depends 'delivery-truck'
