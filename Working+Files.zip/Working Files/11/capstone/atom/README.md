# atom

This cookbook installs the Atom text editor

Usage
-----
Use the `default` recipe to install Atom on Ubuntu and macOS.
