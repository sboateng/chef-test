# chef_workstation

Wrapper cookbook that configures a Chef Developer Workstation

Usage
-----
Use the `default` recipe to install the ChefDK, git and atom on
Ubuntu and macOS.
