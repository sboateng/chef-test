#!/bin/bash

while true; do
  curl localhost:9080
done
