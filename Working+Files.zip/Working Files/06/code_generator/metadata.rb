name             'code_generator'
description      'Custom code generator cookbook for use with ChefDK'
long_description 'Custom code generator cookbook for use with ChefDK'
version          '0.1.0'

