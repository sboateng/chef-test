# default['motd_attributes']['tomcat_home'] = '/usr/local/tomcat8'
# default['motd_attributes']['tomcat_bin'] = "#{node['motd_attributes']['tomcat_home']}/bin/tomcat"
default['motd_attributes']['tomcat_bin'] = '/usr/local/tomcat8/bin/tomcat'
