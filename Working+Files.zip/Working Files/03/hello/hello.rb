file 'hello.txt' do
  content 'Welcome to Chef'
end
