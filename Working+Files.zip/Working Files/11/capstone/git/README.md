# git

Installs git source control

Usage
-----
Use the `default` recipe to install git on Ubuntu and macOS.
