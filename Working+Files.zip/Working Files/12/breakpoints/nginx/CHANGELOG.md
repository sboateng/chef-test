# Nginx Cookbook Changelog

# 1.1.0

ENHANCEMENT:
- Added zero downtime support through reload

# 1.0.0

BREAKING CHANGES:
- Web site configurations must be in /etc/nginx/conf.d not in the main nginx.conf

# 0.1.1

- Integrated build with Travis CI

# 0.1.0

- Initial development
