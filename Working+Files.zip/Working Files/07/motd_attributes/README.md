# motd_attributes

TODO: Enter the cookbook description here.

