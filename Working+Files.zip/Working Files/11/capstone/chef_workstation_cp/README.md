# chef_workstation
This Compliance Profile ensures that a workstation
has the minimum required configuration necessary
for Chef Development
