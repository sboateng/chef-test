# chefdk

Installs the Chef Development Kit

Usage
-----
Use the `default` recipe to install the ChefDK on Ubuntu and macOS.
