chefdk.generator_cookbook = '~/code_generator'
