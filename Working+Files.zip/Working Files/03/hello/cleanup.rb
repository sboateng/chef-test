file "#{ENV['HOME']}/stone.txt" do
  action :delete
end
