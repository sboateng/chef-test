cat /etc/motd
